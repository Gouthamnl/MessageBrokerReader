﻿using System;

namespace SurfStitchService
{
    public class Class1
    {
    }
}
