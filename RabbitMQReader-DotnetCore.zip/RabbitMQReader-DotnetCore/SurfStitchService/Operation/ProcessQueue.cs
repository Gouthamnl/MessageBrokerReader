﻿using ElasticLogger;
using ElasticLogger.Serialization;
using Microsoft.Extensions.Options;
using SurfStitchService.DAL;
using SurfStitchService.Exceptions;
using SurfStitchService.MessageBroker;
using SurfStitchService.Models;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SurfStitchService.Operation
{
    public interface IProcessQueue
    {
        Task ProcessMessage(ProductModel productModel, CancellationToken cancellationToken);
    }
    public class ProcessQueue : IProcessQueue
    {
        private readonly DatabaseOperations _databaseOperations;
        private readonly ConfigurableOptions _configurableOptions;
        private readonly ISerializationManager _serializationManager;
        private readonly IConnectionManager _connectionManager;
        private readonly IElasticSearchLogger _logManager;
        private readonly IMessageBroker _messageBroker;

        public ProcessQueue(IConnectionManager connectionManager, IElasticSearchLogger elasticLogger, ISerializationManager serializationManager, IMessageBroker messageBroker, IOptions<ConfigurableOptions> configurableOptions)
        {
            _connectionManager = connectionManager;
            _logManager = elasticLogger;
            _serializationManager = serializationManager;
            _configurableOptions = configurableOptions.Value;
            _messageBroker = messageBroker;
            _databaseOperations = new DatabaseOperations(elasticLogger, connectionManager);
        }
        public async Task ProcessMessage(ProductModel productModel, CancellationToken cancellationToken)
        {
            try
            {
                await _databaseOperations.InsertDetails(productModel.ProductID, productModel.ProductName, productModel.ProductDescription, cancellationToken);
            }
            catch(NullReferenceException e)
            {
                await _logManager.LogErrorAsync(new LogModel()
                {
                    Message = e.Message,
                    Source = e.Source,
                    EventType = QueueReaderEventType.Exception,
                    LogCategory = LogType.Error
                });
            }
            catch(Exception e)
            {
                await _logManager.LogErrorAsync(new LogModel()
                {
                    Message = e.Message,
                    Source = e.Source,
                    EventType = QueueReaderEventType.Exception,
                    LogCategory = LogType.Error
                });
            }
        }
    }
}
