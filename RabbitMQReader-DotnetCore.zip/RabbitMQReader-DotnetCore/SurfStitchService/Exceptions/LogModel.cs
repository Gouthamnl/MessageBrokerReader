﻿using System;

namespace SurfStitchService.Exceptions
{
    public class LogModel
    {
        public DateTime CreatedDate { get; } = DateTime.UtcNow;

        public LogType LogCategory { get; set; } = LogType.Information;

        public QueueReaderEventType EventType { get; set; }

        public string Message { get; set; }

        public string Type { get; set; }

        public string Source { get; set; }

        public int? HttpStatusCode { get; set; }
    }

    /// <summary>
    /// Logging Category
    /// </summary>
    public enum LogType
    {
        Information,
        Error,
        Critical,
        Warning
    }

    public enum QueueReaderEventType
    {
        Initiated,        
        DatabaseRead,
        DatabaseReadFailure,
        DatabaseUpdate,
        DatabaseUpdateFailure,
        Exception,
        Error,
        Completed,
        Delivered
    }
}
