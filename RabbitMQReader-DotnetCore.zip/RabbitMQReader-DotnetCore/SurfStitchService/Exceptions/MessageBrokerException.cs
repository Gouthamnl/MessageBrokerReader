﻿using System;

namespace SurfStitchService.Exceptions
{
    public class MessageBrokerException : Exception
    {
        public MessageBrokerException(string message)
            : base(message)
        {
        }
    }
}
