﻿using SurfStitchService.Models.MessageBroker;

namespace SurfStitchService.Models
{
    public class ProductModel : BaseMessageModel
    {
        public int ProductID { get; set; }

        public string ProductName { get; set; }

        public string ProductDescription { get; set; }
    }
}
