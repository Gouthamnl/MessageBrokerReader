﻿namespace SurfStitchService.Models.DatabaseModel
{
    public class ServiceDatabase
    {
        public string ConnectionString { get; set; }

        public string DefaultDatabase { get; set; }

        public string DefaultUser { get; set; }

        public string DefaultPassword { get; set; }
    }
}
