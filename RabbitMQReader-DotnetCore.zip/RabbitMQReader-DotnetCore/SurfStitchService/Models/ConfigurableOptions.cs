﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SurfStitchService.Models
{
    public class ConfigurableOptions
    {
        /// <summary>
        /// API Key for the data extraction API
        /// </summary>
        public string APIKey { get; set; }
        /// <summary>
        /// API Uri for the data Extraction
        /// </summary>
        public string DataExtractAPIUri { get; set; }
        /// <summary>
        /// AutoMl Uri for the VAT image classification
        /// </summary>
        public string AutoMlUri { get; set; }
        /// <summary>
        /// Hasvat string to validate
        /// </summary>
        public string Label { get; set; }
        /// <summary>
        /// Minimum confidence value to consider for further process
        /// </summary>
        public double Confidence { get; set; }
        /// <summary>
        /// Enable / Disable Taggun API call
        /// </summary>
        public bool EnableTaggun { get; set; }
        /// <summary>
        /// Enable / Disable Taggun API call
        /// </summary>
        public bool EnableItemize { get; set; }
        /// <summary>
        /// Enable / Disable Auto ML API call
        /// </summary>
        public bool EnableAutoML { get; set; }
        /// <summary>
        /// Scope to generate Google bearer token
        /// </summary>
        public string GoogleAccountScope { get; set; }
        /// <summary>
        /// Itemize API url
        /// </summary>
        public string ItemizeUri { get; set; }
        /// <summary>
        /// Itemize API Key
        /// </summary>
        public string ItemizeApiKey { get; set; }
        /// <summary>
        /// Itemize Account Id
        /// </summary>
        public string ItemizeAccountId { get; set; }
    }
}
