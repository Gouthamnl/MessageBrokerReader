﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SurfStitchService.Models.MessageBroker
{
    public class MessageInfoModel
    {
        public string Data { get; set; }

        public ulong DeliveryTag { get; set; }
    }
}
