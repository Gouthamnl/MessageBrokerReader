﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SurfStitchService.Models.MessageBroker
{
    public class MessageBrokerOptions
    {
        public string Host { get; set; }

        public string RabbitMqUsername { get; set; }

        public string RabbitMqPassword { get; set; }

        public ushort Batch { get; set; }
    }
}
