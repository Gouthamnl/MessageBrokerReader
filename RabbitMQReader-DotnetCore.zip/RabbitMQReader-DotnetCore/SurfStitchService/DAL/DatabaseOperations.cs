﻿using ElasticLogger;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SurfStitchService.DAL
{
    public class DatabaseOperations
    {
        private readonly IConnectionManager _connectionManager;
        private readonly IElasticSearchLogger _logManager;

        public DatabaseOperations(IElasticSearchLogger logManager,IConnectionManager connectionManager)
        {
            _logManager = logManager;
            _connectionManager = connectionManager;
        }

        public async Task<int> InsertDetails(int productId, string productName, string productDescription, CancellationToken cancellation)
        {
            var dbQuery = string.Format(SQLQueries.InsertProduct, productId, productName, productDescription);
            var dbDetails = await _connectionManager.Handle<int>(dbQuery, cancellation);
            return dbDetails.FirstOrDefault();
        }        
    }
}
