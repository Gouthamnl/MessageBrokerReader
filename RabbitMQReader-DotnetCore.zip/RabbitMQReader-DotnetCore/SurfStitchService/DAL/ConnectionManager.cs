﻿using System;
using Dapper;
using ElasticLogger;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Microsoft.Extensions.Options;
using SurfStitchService.Models.DatabaseModel;
using SurfStitchService.Exceptions;

namespace SurfStitchService.DAL
{
    public interface IConnectionManager
    {
        Task<IEnumerable<T>> Handle<T>(string query, CancellationToken cancellationToken);
        Task<int> Handle(string query, CancellationToken cancellationToken);
    }
    public class ConnectionManager : IConnectionManager
    {
        private readonly IElasticSearchLogger _logManager;
        private readonly ServiceDatabase _servicedatabase;

        public ConnectionManager(IElasticSearchLogger logManager, IOptions<ServiceDatabase> servicedatabase)
        {
            _logManager = logManager;
            _servicedatabase = servicedatabase.Value;
        }

        public async Task<IEnumerable<T>> Handle<T>(string query, CancellationToken cancellationToken)
        {
            IEnumerable<T> data = default(IEnumerable<T>);
            try
            {
                var db = _servicedatabase.DefaultDatabase;
                var dbUser = _servicedatabase.DefaultUser;
                var dbPassword = _servicedatabase.DefaultPassword;
                var con = string.Format(_servicedatabase.ConnectionString, db, dbUser, dbPassword);

                cancellationToken.ThrowIfCancellationRequested();
                using (var _connection = new SqlConnection(con))
                {
                    data = await _connection.QueryAsync<T>(query);
                }
            }
            catch(SqlException se)
            {
                await _logManager.LogErrorAsync(new LogModel()
                {
                    Message = se.Message,
                    Source = se.Source,
                    EventType = QueueReaderEventType.Exception,
                    LogCategory = LogType.Error
                });
            }
            catch (Exception e)
            {
                await _logManager.LogErrorAsync(new LogModel
                {
                    Message = $"{e.Message} connection: {_servicedatabase.DefaultDatabase} Query : {query}",
                    Source = "Database Operation",
                    EventType = QueueReaderEventType.Exception,
                    LogCategory = LogType.Critical,
                    HttpStatusCode = 500
                }, cancellationToken);
                return null;
            }
            return data;
        }

        public async Task<int> Handle(string query, CancellationToken cancellationToken)
        {
            int res = -1;
            try
            {
                var db = _servicedatabase.DefaultDatabase;
                var dbUser = _servicedatabase.DefaultUser;
                var dbPassword = _servicedatabase.DefaultPassword;
                var con = string.Format(_servicedatabase.ConnectionString, db, dbUser, dbPassword);

                cancellationToken.ThrowIfCancellationRequested();
                using (var _connection = new SqlConnection(con))
                {
                    using (SqlCommand cmd = new SqlCommand(query, _connection))
                    {
                        _connection.Open();
                        res = cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (SqlException se)
            {
                await _logManager.LogErrorAsync(new LogModel()
                {
                    Message = se.Message,
                    Source = se.Source,
                    EventType = QueueReaderEventType.Exception,
                    LogCategory = LogType.Error
                });
            }
            catch (Exception e)
            {
                await _logManager.LogErrorAsync(new LogModel
                {
                    Message = $"{e.Message} connection: {_servicedatabase.DefaultDatabase} Query : {query}",
                    Source = "Database Operation",
                    EventType = QueueReaderEventType.Exception,
                    LogCategory = LogType.Critical,
                    HttpStatusCode = 500
                }, cancellationToken);
                return -1;
            }
            return res;
        }
    }
}
