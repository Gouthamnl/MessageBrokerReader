﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SurfStitchService.DAL
{
    public class SQLQueries
    {
        public const string InsertProduct = @"
            INSERT INTO Products 
                   (ProductID, ProductName, ProductDescription)
            VALUES ({0}, '{1}', '{2}');";
    }
}
