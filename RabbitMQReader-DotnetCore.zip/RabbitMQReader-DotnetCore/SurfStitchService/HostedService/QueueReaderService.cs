﻿using System;
using System.Threading;
using System.Threading.Tasks;
using ElasticLogger;
using Microsoft.Extensions.Options;
using SurfStitchService.Exceptions;
using SurfStitchService.MessageBroker;
using SurfStitchService.Models;
using SurfStitchService.Models.MessageBroker;
using SurfStitchService.Operation;

namespace SurfStitchService.HostedServices
{
    public class QueueReaderService : HostedService
    {
        private readonly IElasticSearchLogger _logManager;
        private readonly IMessageBroker _messageBroker;
        private readonly MessageBrokerOptions _options;
        private readonly IProcessQueue _processQueue;

        public QueueReaderService(IElasticSearchLogger logManager, IMessageBroker messageBroker, IProcessQueue processQueue, IOptions<MessageBrokerOptions> options)
        {
            _logManager = logManager;
            _messageBroker = messageBroker;
            _options = options.Value;
            _processQueue = processQueue;

        }

        public override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            try
            {
                await _logManager.LogInfoAsync(new LogModel
                {
                    Message = $"QueueReader service called !",
                    EventType = QueueReaderEventType.Initiated
                }, stoppingToken);

                // get data from rabbitMQ 

                var subscriptionInfo = await subscribeToMessageBroker<ProductModel>(stoppingToken);


                // process data and update 

                subscriptionInfo.OnReceivedAsync += _processQueue.ProcessMessage;


                var dat = subscriptionInfo.OnErrorAsync += async (message, ex, CancellationToken) =>
                {
                    Console.WriteLine(ex?.Message);
                    await _logManager.LogInfoAsync(new LogModel
                    {
                        Message = ex?.Message,
                        EventType = QueueReaderEventType.Error
                    }, stoppingToken);
                    await Task.Delay(1000);
                };
                await _messageBroker.ProcessMessagesAsync(subscriptionInfo, stoppingToken);                

            }
            catch (TaskCanceledException ex)
            {
                await _logManager.LogErrorAsync(new LogModel
                {
                    Message = ex.Message,
                    EventType = QueueReaderEventType.Exception,
                    LogCategory = LogType.Critical,
                    HttpStatusCode = 500
                }, stoppingToken);

            }
            catch (OperationCanceledException ex)
            {
                await _logManager.LogErrorAsync(new LogModel
                {
                    Message = ex.Message,
                    EventType = QueueReaderEventType.Exception,
                    LogCategory = LogType.Critical,
                    HttpStatusCode = 500
                }, stoppingToken);
            }
            catch (Exception ex)
            {
                await _logManager.LogErrorAsync(new LogModel
                {
                    Message = ex.Message,
                    EventType = QueueReaderEventType.Exception,
                    LogCategory = LogType.Critical,
                    HttpStatusCode = 500
                }, stoppingToken);
            }

        }

        private Task<SubscriptionInfoModel<T>> subscribeToMessageBroker<T>(CancellationToken stoppingToken) where T : BaseMessageModel
        {
            return Task.FromResult
            (
                new SubscriptionInfoModel<T>()
                {
                    Exchange = Constants.AMQPSurfStitchExchange,
                    Queue = Constants.AMQPSurfStitchQueue,
                    RoutingKey = Constants.AMQPRoute,
                    Requeue = true,
                }
            );
        }
    }
}
