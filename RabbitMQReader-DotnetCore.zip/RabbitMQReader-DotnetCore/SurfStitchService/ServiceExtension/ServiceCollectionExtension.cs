﻿using ElasticLogger;
using ElasticLogger.Serialization;
using Microsoft.Extensions.DependencyInjection;
using SurfStitchService.DAL;
using SurfStitchService.HostedServices;
using SurfStitchService.MessageBroker;
using SurfStitchService.Operation;

namespace SurfStitchService.ServiceExtensions
{
    public static class ServiceCollectionExtension
    {
        public static IServiceCollection AddServiceDependencies(this IServiceCollection services)
        {
            services.AddSingleton<IMessageBroker, RabbitMQBroker>();
            services.AddScoped<IProcessQueue, ProcessQueue>();
            services.AddScoped<IConnectionManager, ConnectionManager>();
            services.AddScoped<IElasticSearchLogger, ElasticSearchLogger>();
            services.AddScoped<ISerializationManager, JsonSerializationManager>();
            services.AddHostedService<QueueReaderService>();
            return services;
        }
    }
}
