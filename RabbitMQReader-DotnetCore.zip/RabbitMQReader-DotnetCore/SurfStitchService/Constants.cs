﻿namespace SurfStitchService
{
    public class Constants
    {
        public const string LogDnaURL = "https://logs.logdna.com/logs/ingest?hostname={0}&now={1}";        
        public const string AMQPSurfStitchExchange = "SurfStitchExchange";
        public const string AMQPSurfStitchQueue = "SurfStitchQueue";
        public const string AMQPRoute = "SurfStitchRoutingKey";
        public const string ElasticUrl = "http://localhost:9200/surfstitch/log";
    }
}
