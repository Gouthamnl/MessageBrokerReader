﻿using ElasticLogger.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SurfStitchService.Models;
using SurfStitchService.Models.DatabaseModel;
using SurfStitchService.Models.MessageBroker;
using SurfStitchService.ServiceExtensions;
using System;
using System.IO;
using System.Threading.Tasks;

namespace SurfStitchRunner
{
    class Program
    {
        static void Main(string[] args)
        {
            createHost().Wait();
        }

        static async Task createHost()
        {
            var builder = new ConfigurationBuilder()
                           .SetBasePath(Path.Combine(AppContext.BaseDirectory))
                           .AddJsonFile("appSettings.json", optional: true);

            var configuration = builder.Build();

            var host = new HostBuilder()
                .ConfigureServices((hostContext, services) =>
                {
                    services.AddServiceDependencies();
                    services.AddOptions<ConfigurableOptions>().Configure(options => configuration.GetSection(nameof(ConfigurableOptions)).Bind(options));
                    services.AddOptions<MessageBrokerOptions>().Configure(options => configuration.GetSection(nameof(MessageBrokerOptions)).Bind(options));
                    services.AddOptions<ServiceDatabase>().Configure(options => configuration.GetSection(nameof(ServiceDatabase)).Bind(options));
                    services.AddOptions<LogOptions>().Configure(options => configuration.GetSection(nameof(LogOptions)).Bind(options));

                })
                .UseConsoleLifetime()
                .Build();


            await host.RunAsync();



        }
    }
}
