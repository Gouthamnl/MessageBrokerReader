﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ElasticLogger.Models
{
    public class LogOptions
    {
        public string LogUrl { get; set; }

        public string LogFilePath { get; set; }

        
    }
}
