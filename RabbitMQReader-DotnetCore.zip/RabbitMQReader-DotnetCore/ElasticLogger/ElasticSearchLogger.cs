﻿using ElasticLogger.Models;
using ElasticLogger.Serialization;
using Serilog.Core;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;

namespace ElasticLogger
{
    public interface IElasticSearchLogger
    {
        Task LogInfoAsync<T>(T obj, CancellationToken cancellationToken);
        Task LogErrorAsync<T>(T obj, CancellationToken cancellationToken);
        Task LogInfoAsync<T>(T obj);
        Task LogErrorAsync<T>(T obj);
    }

    public class ElasticSearchLogger : IElasticSearchLogger
    {
        private readonly ISerializationManager _serializationManager;
        private readonly LogOptions _configurableOptions;
        public Logger _logger;

        public ElasticSearchLogger(ISerializationManager serializationManager, IOptions<LogOptions> configurableOptions)
        {
            _serializationManager = serializationManager;
            _configurableOptions = configurableOptions.Value;
        }
        public async Task LogInfoAsync<T>(T obj, CancellationToken cancellationToken)
        {           
            try
            {                
                using (var _httpClient = new HttpClient())
                {
                    var request = new HttpRequestMessage(HttpMethod.Post, _configurableOptions.LogUrl);
                    _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    request.Content = new StringContent(this._serializationManager.Serialize(obj), Encoding.UTF8, "application/json");
                    await _httpClient.SendAsync(request, cancellationToken);
                }

            }
            catch (Exception ex)
            {
                var f = ex;
            }
        }

        public async Task LogErrorAsync<T>(T obj, CancellationToken cancellationToken)
        {            
            try
            {
                using (var _httpClient = new HttpClient())
                {
                    var request = new HttpRequestMessage(HttpMethod.Post, _configurableOptions.LogUrl);
                    _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    request.Content = new StringContent(this._serializationManager.Serialize(obj), Encoding.UTF8, "application/json");
                    await _httpClient.SendAsync(request, cancellationToken);
                }

            }
            catch (Exception ex)
            {
                var f = ex;
            }
        }        

        public async Task LogInfoAsync<T>(T obj)
        {            
            try
            {
                using (var _httpClient = new HttpClient())
                {
                    var request = new HttpRequestMessage(HttpMethod.Post, _configurableOptions.LogUrl);
                    _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    request.Content = new StringContent(this._serializationManager.Serialize(obj), Encoding.UTF8, "application/json");
                    await _httpClient.SendAsync(request);
                }

            }
            catch (Exception ex)
            {
                var f = ex;
            }
        }

        public async Task LogErrorAsync<T>(T obj)
        {            
            try
            {
                using (var _httpClient = new HttpClient())
                {
                    var request = new HttpRequestMessage(HttpMethod.Post, _configurableOptions.LogUrl);
                    _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    request.Content = new StringContent(this._serializationManager.Serialize(obj), Encoding.UTF8, "application/json");
                    await _httpClient.SendAsync(request);
                }

            }
            catch (Exception ex)
            {
                var f = ex;
            }
        }
    }
}
